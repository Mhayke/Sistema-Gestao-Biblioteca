package controller;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import dao.CategoriaDAO;
import dao.LivroDAO;
import model.Categoria;
import model.Livro;
import view.Ui;

public class Events {

	public void inicializar() throws SQLException {
		
		Ui ui = new Ui();
		Scanner scan = new Scanner(System.in);
		
		int opt;
		do { // loop de repetição do Menu Principal usando do-While
			ui.exibirMenu();
			System.out.print(" DIGITE UMA OPÇÃO: ");
			opt = scan.nextInt();
			
			switch(opt) { // Opções de casos utilizando os cases do switch!
			
			case 1: // Opção de Gerenciamento de Livro
				
				int optl;
				do {
					ui.exibirGlivros();
					System.out.print(" DIGITE UMA OPÇÃO: ");
					optl = scan.nextInt();
					scan.nextLine(); // limpar o buff
					
					if (optl == 1) { // opção de cadastrar livro
						
						Livro lv = new Livro();
						LivroDAO daolv = new LivroDAO();
						
						ui.exibirNom();
						System.out.print("DIGITE O NOME DO LIVRO: ");
						String titulo = scan.nextLine();
						lv.setTitulo(titulo);
						
						ui.exibirAut();
						System.out.print("DIGITE O NOME DO AUTOR: ");
						String autor = scan.nextLine();
						lv.setAutor(autor);
						
						ui.exibirSinop();
						System.out.print("DIGITE A SINOPSE DO LIVRO: ");
						String sinopse = scan.nextLine();
						lv.setSinopse(sinopse);
						
						ui.exibirIsbn();
						System.out.print("DIGITE O ISBN DO LIVRO: ");
						String isbn = scan.nextLine();
						lv.setIsbn(isbn);    
					
						LocalDate localDate = null;
						
						do {	
							ui.exibirDat();
							System.out.print("DIGITE A DATA DE LANÇAMENTO DO LIVRO (dd/MM/yyyy): ");
							String anolancamento = scan.nextLine();
							DateTimeFormatter ft = DateTimeFormatter.ofPattern("dd/MM/yyyy"); // formatar a string em localDate
							localDate = LocalDate.parse(anolancamento, ft); // transforma string e formato em Localdate
							
							if (localDate.getYear() >= 1967) {
								lv.setAnolancamento(localDate);
								continue;
							} else {
								System.out.println(" ERRO DIGITE UM ANO DE LANÇAMENTO VALIDO!");
							}
							
						} while (localDate.getYear() < 1967); // condição para verificar a data
						
						Categoria resultado = null;
						
						do {
							CategoriaDAO daoct = new CategoriaDAO();
							List<Categoria> categ = daoct.findAll();
							
							System.out.println("\n╔═════════════════════════════╗");
							System.out.println("     CATEGORIA DO LIVRO 📖");
							System.out.println("╚═════════════════════════════╝");
							System.out.println("╔═════════════════════════════╗");
							
							for (Categoria categoria : categ) {
								
								System.out.println("  Categoria: "+categoria.getNome() +" "+ "[ID: "+categoria.getId()+"]");
								
							}
							System.out.println("╚═════════════════════════════╝");
							System.out.print("DIGITE O (ID) DA CATEGORIA DESEJADA: ");
							Integer idct = scan.nextInt();
							scan.nextLine(); // limpa o buffer
							resultado = daoct.findById(idct);
	
							if (resultado != null) {
								lv.setCategoria(resultado);
								daolv.salvarliv(lv); // metodo para salvar o livro
								ui.exibirSucLiv(); // mensagem de livro cadastrado.
							} else {
								ui.exibirErrorCateg(); // mensagem de erro caso não tenha uma categoria valida
							}
						
						} while (resultado == null); // condição para 'forçar' uma categoria valida
						
					} else if (optl == 2) { // opção de excluir livro
						
						LivroDAO daolv = new LivroDAO();
						
						ui.exibirRlivro();
						System.out.print("DIGITE O ISBN DO LIVRO PARA (EXCLUSÃO): ");
						String isbn = scan.nextLine();
						Boolean resultado = daolv.deletarByIsbn(isbn);
						
						if (resultado == true) {
							ui.exibirSRlivro();
						} else {
							ui.exibirRRlivro();
						}
						
					} else if (optl == 3) { // opção para atualizar livro
						
						LivroDAO daolv = new LivroDAO();
						
						System.out.print("\nINFORME O ISBN DO LIVRO QUE DESEJA ATUALIZAR: ");
			            String isbnantigo = scan.nextLine();
			         
			            List<Livro> lvant = daolv.findByIsbn(isbnantigo);
			            
			            System.out.print("\nO QUE DESEJA ATUALIZAR ? (titulo, autor, sinopse, isbn, data, categoria): ");
			            String campo = scan.nextLine().toLowerCase();
			            
			            if (campo.equalsIgnoreCase("titulo")) {
			            	
			            	ui.exibirNom();
			            	System.out.print("DIGITE O TITULO DO LIVRO PARA (ATUALIZAÇÃO): ");
			            	String titulo = scan.nextLine();
			            	
			            	for (Livro livro : lvant) {
			            		livro.setTitulo(titulo);
			            		daolv.atualizarliv(livro);
			            		ui.exibirAtualSuces();
							}
			            	
						} else if (campo.equalsIgnoreCase("autor")) {
							
							ui.exibirAut();
							System.out.print("DIGITE O AUTOR DO LIVRO PARA (ATUALIZAÇÃO): ");
							String autor = scan.nextLine();
							
							for (Livro livro : lvant) {
								livro.setAutor(autor);
								daolv.atualizarliv(livro);
								ui.exibirAtualSuces();
							}
							
						} else if (campo.equalsIgnoreCase("sinopse")) {
							
							ui.exibirSinop();
							System.out.print("DIGITE A SINOPSE DO LIVRO PARA (ATUALIZAÇÃO): ");
							String sinopse = scan.nextLine();
							
							for (Livro livro : lvant) {
								livro.setSinopse(sinopse);
								daolv.atualizarliv(livro);
								ui.exibirAtualSuces();
							}
							
						} else if (campo.equalsIgnoreCase("isbn")) {
							
							ui.exibirIsbn();
							System.out.print("DIGITE O ISBN DO LIVRO PARA (ATUALIZAÇÃO): ");
							String isbn = scan.nextLine();
							
							for (Livro livro : lvant) {
								livro.setIsbn(isbn);
								daolv.atualizarliv(livro);
								ui.exibirAtualSuces();
							}
							
						} else if (campo.equalsIgnoreCase("categoria")) {
							
							CategoriaDAO daoct = new CategoriaDAO();
							List<Categoria> categ = daoct.findAll();
							
							System.out.println("\n╔═════════════════════════════╗");
							System.out.println("     CATEGORIA DO LIVRO 📖");
							System.out.println("╚═════════════════════════════╝");
							System.out.println("╔═════════════════════════════╗");
							
							for (Categoria categoria : categ) {
								
								System.out.println("  Categoria: "+categoria.getNome() +" "+ "[ID: "+categoria.getId()+"]");
								
							}
							System.out.println("╚═════════════════════════════╝");
							System.out.print("DIGITE A CATEGORIA DO LIVRO PARA (ATUALIZAÇÃO): ");
							Integer categor = scan.nextInt();
							
							for (Livro livro : lvant) {
								livro.getCategoria().setId(categor);
								daolv.atualizarliv(livro);
								ui.exibirAtualSuces();
							}
							
						} else if (campo.equalsIgnoreCase("data")) {
							
							ui.exibirDat();
							System.out.print("DIGITE A DATA DO LIVRO PARA ATUALIZAÇÃO (dd/MM/yyyy): ");
							String anoLancamento = scan.nextLine();
							DateTimeFormatter ft = DateTimeFormatter.ofPattern("dd/MM/yyyy"); // formatar a string em localDate
							LocalDate localDate = LocalDate.parse(anoLancamento, ft); // transformar string e Localdate em Date
							
							for (Livro livro : lvant) {
								livro.setAnolancamento(localDate);
								daolv.atualizarliv(livro);
								ui.exibirAtualSuces();
							}
						}
							
					} else if (optl == 4) { // opção para listar todos os livros
							
							LivroDAO daolv = new LivroDAO();
							
							List<Livro> livros = daolv.findAll();
							
							System.out.println("╔═════════════════════════════════════════╗\n"
									+ "	TODOS OS LIVROS CADASTRADOS 📓");
							
							for (Livro ls : livros) {
								
								System.out.println("\n");
								System.out.println("[CÓDIGO]: " + ls.getCodigo());
								System.out.println("[TÍTULO]: " + ls.getTitulo() + " [AUTOR]: " + ls.getAutor() + " [ISBN]: " + ls.getIsbn());
								System.out.println("[SINOPSE]: " + ls.getSinopse() + " [ANO DE LANÇAMENTO]: " + ls.getAnolancamento());
								System.out.println();
							}
							System.out.println("\n");
							System.out.println("\n╚═════════════════════════════════════════╝");
							
					} else if (optl == 5) { // opção para buscar livro por isbn
						
						LivroDAO daolv = new LivroDAO();
						
						System.out.print("\nQUAL O (ISBN) QUE DESEJA BUSCAR?: ");
						String isbn = scan.nextLine();
						
						List<Livro> livro = daolv.findByIsbn(isbn);
						
						for (Livro ls : livro) {
							System.out.println("\n╔═════════════════════════════════════════╗");
							System.out.println("    RESULTADO DO ISBN:"+ ls.getIsbn() + " ENCONTRADO ✅\n");
							System.out.println("[CÓDIGO]: " + ls.getCodigo());
							System.out.println("[TÍTULO]: " + ls.getTitulo() + " [AUTOR]: " + ls.getAutor() + " [ISBN]: " + ls.getIsbn());
							System.out.println("[SINOPSE]: " + ls.getSinopse() + " [ANO DE LANÇAMENTO]: " + ls.getAnolancamento());
							System.out.println("\n╚═════════════════════════════════════════╝");
						}
						
					} else if (optl == 6) { // opção para buscar livro por autor
						
						LivroDAO daolv = new LivroDAO();
						
						System.out.print("\nQUAL O (NOME) DO AUTOR QUE DESEJA BUSCAR?: ");
						String autor = scan.nextLine();
						
						List<Livro> livro = daolv.findByAutor(autor);
						
						System.out.println("\n╔═════════════════════════════════════════╗");
						System.out.println("        RESULTADO DO AUTOR:"+ autor + " 📓\n");
						
						for (Livro ls : livro) {
							System.out.println("[Código]: " + ls.getCodigo());
							System.out.println("[Título]: " + ls.getTitulo() + " [Autor]: " + ls.getAutor() + " [ISBN]: " + ls.getIsbn());
							System.out.println("[Sinopse]: " + ls.getSinopse());
							System.out.println("[Ano de Lançamento]: " + ls.getAnolancamento() + " [Categoria]: ");
							System.out.println("\n");
						}
						System.out.println("╚═════════════════════════════════════════╝");
						
					} else if (optl == 7) {
						
						CategoriaDAO daoct = new CategoriaDAO();
						List<Categoria> categorias = daoct.findAll();
						
						System.out.println("\n╔═══════════════════════════════════════════╗");
						System.out.println("           LIVROS POR CATEGORIA 📓\n");
						for (Categoria ctlv : categorias) {
							System.out.println("    \n[CATEGORIA]: " + ctlv.getNome() + " [CODIGO]: " + ctlv.getId() + "\n");
							for (Livro lvs : ctlv.getLivros()) {
								System.out.println("[TITULO]: "+ lvs.getTitulo() + " [AUTOR]: " + lvs.getAutor() + " [ISBN]: " + lvs.getIsbn());
							}
						}
						System.out.println("\n╚═══════════════════════════════════════════╝");
						
					} else if (optl == 8) { // opção para voltar ao menu principal
						break; // encerra o loop do-while
					} else {
						ui.exibir404invalid(); // exibe mensagem de 'opção invalida'
					}
					
				} while (optl != 8);
				
				break; // encerra o switch case
				
			case 2: // Opção de Gerenciamento de Categoria
				
				int optc;
				do {
					ui.exibirGcategoria();
					System.out.print(" DIGITE UMA OPÇÃO: ");
					optc = scan.nextInt();
					scan.nextLine(); // limpar o buff
					
					if (optc == 1) { // opção de cadastrar categoria
						
						Categoria cat = new Categoria();
						CategoriaDAO daocat = new CategoriaDAO();
						
						Categoria result; 
						do {
							ui.exibirNomCateg();
							System.out.print("DIGITE O NOME DA CATEGORIA: ");
							String nome = scan.nextLine().toUpperCase(); // Deixa a captura de (nome) Maiuscula
							result = daocat.findByName(nome);
							
							if (result != null) {
								System.out.println("\n CATEGORIA CADASTRADA! ESCOLHA UM NOME DIFERENTE ⚠️");
							} else {
								cat.setNome(nome);
							}
							
						} while (result != null); // loop para caso tenha categoria existente
						
						ui.exibirDesCateg();
						System.out.print("DIGITE A DESCRIÇÃO DA CATEGORIA: ");
						String desc = scan.nextLine();
						cat.setDescricao(desc);
						
						daocat.savecat(cat);
						ui.exibirCategSuces();
						
					} else if (optc == 2) { // opção de excluir categoria
						
						CategoriaDAO daoct = new CategoriaDAO();
						
						Categoria result;
						Boolean resp;
						do {
							ui.exibirRemCateg();
							System.out.print("DIGITE O CODIGO DA CATEGORIA PARA (EXCLUSÃO): ");
							Integer cod = scan.nextInt();
							result = daoct.findById(cod);
							
							if (result != null) {
								resp = daoct.deletecat(cod);
								if (resp == false) {
									System.out.println("\n ESTÁ CATEGORIA CONTÉM LIVROS, NÃO PODE SER EXCLUÍDA! ⚠️");
								}	
							} else {
								System.out.println("\n CODIGO INEXISTENTE! DIGITE NOVAMENTE ⚠️");
							}
						} while (result == null);
						
					} else if (optc == 3) { // opção para atualizar categoria
						
						CategoriaDAO daoct = new CategoriaDAO();
						
						Categoria resultado;
						do {
							ui.exibirCodCateg();
							System.out.print("INFORME O (ID) DA CATEGORIA QUE DESEJA (ATUALIZAR): ");
				            Integer codant = scan.nextInt();
				            scan.nextLine(); // Limpa o buffer
				            
				            resultado = daoct.findById(codant);
				            
				            if (resultado != null) {
				          
				            	while (true) {
					            	System.out.print("\nO QUE DESEJA ATUALIZAR ? (nome, descricao): ");
						            String campo = scan.nextLine().toLowerCase();
						            
						            if (campo.equalsIgnoreCase("nome")) {
						            	ui.exibirNomCateg();
						            	System.out.print("DIGITE O NOME DA CATEGORIA PARA (ATUALIZAÇÃO): ");
						            	String nome = scan.nextLine().toUpperCase();
						            	resultado.setNome(nome);
						            	break;
									} else if (campo.equalsIgnoreCase("descricao")) {
										ui.exibirDesCateg();
										System.out.print("DIGITE A DESCRIÇÃO DA CATEGORIA PARA (ATUALIZAÇÃO): ");
										String desc = scan.nextLine().toUpperCase();
										resultado.setDescricao(desc);
										break;
									} else {
										ui.exibir404invalid();
									}
				            	}
					            daoct.updatecat(resultado);
					            ui.exibirAtualSuces();
							} else {
								System.out.println("\n (ID) INEXISTENTE! TENTE NOVAMENTE ⚠️");
								break;
							}
						} while (resultado == null);

					} else if (optc == 4) { // opção listar todas as categorias

						CategoriaDAO daoct = new CategoriaDAO();
						List<Categoria> categ = daoct.findAll();
						
						System.out.println("\n╔═══════════════════════════════╗");
						System.out.println("       TODAS AS CATEGORIAS 📖\n");
				
						for (Categoria categoria : categ) {
							
							System.out.println("  Categoria: "+categoria.getNome() +" "+ "[ID: "+categoria.getId()+"]");
							
						}
						System.out.println("\n╚═══════════════════════════════╝");
						
					} else if (optc == 5) { // buscar categoria por id
						
						CategoriaDAO daoct = new CategoriaDAO();
						
						Categoria resultado;
						do {	
							ui.exibirCodCateg();
							System.out.print("QUAL O (ID) QUE DESEJA BUSCAR?: ");
							Integer cod = scan.nextInt();
							resultado = daoct.findById(cod);
							
							if (resultado != null) {
								System.out.println("\n╔═══════════════════════════════════════╗");
								System.out.println("        RESULTADO SOBRE O ID: "+ cod + " 📖\n");
								
								System.out.println("\n [CATEGORIA]: " + resultado.getNome() + " [CODIGO]: " + resultado.getId() + "\n");
								System.out.println(" [DESCRIÇÃO]: "+ resultado.getDescricao());
								
								System.out.println("\n╚═══════════════════════════════════════╝");
							} else {
								System.out.println("\n (ID) INEXISTENTE! DIGITE NOVAMENTE ⚠️");
								break;
							}
						
						} while (resultado == null);
						
					} else if (optc == 6) { // exibir categorias com maior indice de livros em ordem decrescente
							
						CategoriaDAO daoct = new CategoriaDAO();
						List<Categoria> categ = daoct.findAll();
						
						// COLLECTIONS.SORT ordena a lista passada no caso 'categ' / pela quantidade de livros
					    Collections.sort(categ, new Comparator<Categoria>() { // criando um comparador personalizado
					        @Override // anotação para indicar que um método está sobrescrevendo um método da SuperClasse
					        public int compare(Categoria c1, Categoria c2) {
					            return Integer.compare(c2.getLivros().size(), c1.getLivros().size()); // comparando o tamanho da lista de livros das duas categorias
					        }
					    });
					    System.out.println("\n╔═══════════════════════════════════════╗");
					    System.out.println("   QUANTIDADE DE LIVROS P/ CATEGORIA 📖 ");
						for (Categoria ct : categ) { // percorre a lista ja ordenada 
							System.out.println("\n[CATEGORIA]: " + ct.getNome() + " [Qtd. Livros]: " + ct.getLivros().size()); // imprime o resultado com nome e qnt. de livros em ordem descrecente
							
						}
						System.out.println("\n╚═══════════════════════════════════════╝");
						
					} else if (optc == 7) {
						break; // encerra o loop do-while
					} 
					else {
						ui.exibir404invalid(); // exibe mensagem de 'opção invalida'
					}
					
				} while (optc != 7);
				
				break; // encerra o switch case
				
			case 3: // Finaliza o loop do-While e encerra o programa.
				ui.exibirSaida();
				return;
			
			default: // Quando não ha uma opção numerica valida! 
				ui.exibir404invalid();
			}
			
		} while (opt != 3); // Condição de encerrar o programa.
	}
	
}
