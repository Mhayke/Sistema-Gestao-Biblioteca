package model;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity 
@Table(name = "categorias", schema = "public") // define o nome da tabela no bd
public class Categoria {
	
	@Id // define a (primary key)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "mycat" ) // estrategia de sequencia numeral no bd
	@SequenceGenerator(name = "mycat", allocationSize = 1, initialValue = 1 ) // gerador com valor inicial
	private Integer id;
	
	 @Column(nullable = false, unique = true) // unique fazendo o nome da categoria ser unico ao cadastrar
	private String nome;
	 
	private String descricao;
	
	@OneToMany(mappedBy = "categoria", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<Livro> livros;
	 
	// gett's e sett's
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public List<Livro> getLivros() {
		return livros;
	}

	public void setLivros(List<Livro> livros) {
		this.livros = livros;
	}
	

}
