package model;

import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity // determina a classe "Livro" como uma tabela
@Table(name = "livros", schema = "public") // define o nome da tabela no bd
public class Livro {
	
	@Id // define a (primary key)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "myliv" ) // estrategia de sequencia numeral no bd
	@SequenceGenerator(name = "myliv", allocationSize = 1, initialValue = 1 ) // gerador com valor inicial
	private Integer codigo;
	
	@Column(nullable = false) // 'nullable' para obrigação do preenchimento de campo
	private String titulo;
	
	@Column(nullable = false)
	private String autor;
	
	@Column(nullable = false)
	private String sinopse;
	
	@Column(nullable = false, unique = true, length = 13) // 'unique' para deixar o campo unico no bd, 'lengh' tamanho max.
	private String isbn;
	
	@Column(nullable = false)
	private LocalDate anolancamento;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "categoria_id", nullable = false)
	private Categoria categoria;

	
	// gett's e sett's
	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public String getSinopse() {
		return sinopse;
	}

	public void setSinopse(String sinopse) {
		this.sinopse = sinopse;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public LocalDate getAnolancamento() {
		return anolancamento;
	}

	public void setAnolancamento(LocalDate anolancamento) {
		this.anolancamento = anolancamento;
	}

	public Categoria getCategoria() {
		return categoria;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}	

}
