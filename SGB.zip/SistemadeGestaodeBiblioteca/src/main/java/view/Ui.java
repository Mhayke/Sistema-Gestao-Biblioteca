package view;

public class Ui {

	// Menus Principal
		public String MenuPrincipal = """
				╔═════════════════════════════════════╗
				   SISTEMA DE GESTÃO BIBLIOTECÁRIO ✏️              
				║═════════════════════════════════════║
				  1. Gerenciar Livros 📓  
				  2. Gerenciar Categoria 📖 
				  3. Sair ➡️                                       
				╚═════════════════════════════════════╝ 
				""";
		
		public String MenuGlivros = """
				╔══════════════════════════════════════════════════╗ 
				            📓 GERENCIAMENTO DE LIVROS 📓
				╠══════════════════════════════════════════════════╣
				║ 1. Cadastrar Livro   4. Listar Todos os Livros   ║
				║ 2. Excluir Livro     5. Buscar L. por ISBN       ║
				║ 3. Atualizar Livro   6. Listar L. por Autor      ║
				║ 8. Voltar            7. Listar L. por Categoria  ║
				╚══════════════════════════════════════════════════╝
				"""; 
		
		public String MenuGcategoria = """
				╔══════════════════════════════════════════════════════════════╗ 
				                  📖 GERENCIAMENTO DE CATEGORIA 📖
				╠══════════════════════════════════════════════════════════════╣
				║ 1. Cadastrar Categoria   4. Listar Todas as Categorias       ║
				║ 2. Excluir Categoria     5. Buscar Categoria por Codigo      ║
				║ 3. Atualizar Categoria   6. Exibir Categoria por Qnt. Livros ║
				║ 7. Voltar                                                    ║
				╚══════════════════════════════════════════════════════════════╝
				""";
		
		public String MenuSair = """
				╔═══════════════════════════════════════════════════════╗ 
				           SISTEMA DE GESTÃO BIBLIOTECÁRIO ✏️
				╠═══════════════════════════════════════════════════════╣
				║ AGRADEÇEMOS A USABILIDADE DE NOSSO SISTEMA, ATÉ LOGO. ║
				╚═══════════════════════════════════════════════════════╝
				""";
		
		public String MenuError = """
				╔═════════════════════════════════════════════╗ 
				      OPÇÃO INVÁLIDA ESCOLHA NOVAMENTE! ⚠️
				╚═════════════════════════════════════════════╝
				""";
		
		// Metodos ou funções para exibir mini interfaces para melhor visualização de opções
		
		public void exibirMenu() { // Exibi a interface de Menu Principal.
			System.out.print("\n"+MenuPrincipal);
		}
		
		public void exibirGlivros() { // Exibi a interface Gerenciamento de Livro.
			System.out.print("\n"+MenuGlivros);
		}
		
		public void exibirGcategoria() { // Exibi a interface Gerenciamento de Categoria.
			System.out.print("\n"+MenuGcategoria);
		}
		
		public void exibirSaida() { // Exibi a interface de saida.
			System.out.println("\n"+MenuSair);
		}
		
		public void exibir404invalid() { // Exibi a mensagem de 'Opção invalida'
			System.out.println("\n"+MenuError);
		}
		
		
		// Blocos de String's para criar mini interface a ser usado para mostrar ao usuario em cadastrar livros
		
		public String MenuNom = """
				╔═════════════════════════════╗ 
				        NOME DO LIVRO 📓
				╚═════════════════════════════╝
				""";
		
		public String MenuAut = """
				╔═════════════════════════════╗ 
				        AUTOR DO LIVRO 📓
				╚═════════════════════════════╝
				""";
		
		public String MenuSinop = """
				╔═════════════════════════════╗ 
				       SINOPSE DO LIVRO 📓
				╚═════════════════════════════╝
				""";
		
		public String MenuIsbn = """
				╔═════════════════════════════╗ 
				    NÚMERO ISBN DO LIVRO 📓
				╚═════════════════════════════╝
				""";
		
		public String MenuDat = """
				╔═════════════════════════════╗ 
				      DATA DE LANÇAMENTO 📓
				╚═════════════════════════════╝
				""";
		
		/*public String MenuPreco = """
				╔═════════════════════════════╗ 
				       PREÇO DO LIVRO $📓
				╚═════════════════════════════╝
				""";*/
		
		/*public String MenuCateg = """
						 ╔═════════════════════════════╗ 
						      CATEGORIA DO LIVRO 📖
						 ╚═════════════════════════════╝
				╔════════════════════════════════════════════════════════════════╗ 
				  1. Terror         2. Fantasia     3. Ficção     4. Romance
				  5. Mangá          6. Biografia    7. Infantil   8. HQ
				  9. Religião      10. Tecnologia   11. Esportes  12. Artes
				  13. Gastronomia  14. Ciência      15. Aventura  16. Psicologia
				╚════════════════════════════════════════════════════════════════╝
				""";*/
		
		public String MenuSucLiv = """
				╔════════════════════════════════════════╗
				║    LIVRO CADASTRADO COM SUCESSO ✅ 	 ║
				╚════════════════════════════════════════╝
				""";
		
		public String MenuCatError = """
				╔═══════════════════════════════════════════════════╗
				║    CATEGORIA INEXISTENTE! ESCOLHA NOVAMENTE ❌	    ║
				╚═══════════════════════════════════════════════════╝
				""";
		
		// Metodos ou funções para exibir mini interfaces para melhor visualização de opções
		
		public void exibirNom() {
			System.out.println("\n"+MenuNom);
		}
		
		public void exibirAut() {
			System.out.println("\n"+MenuAut);
		}
		
		public void exibirSinop() {
			System.out.println("\n"+MenuSinop);
		}
		
		public void exibirIsbn() {
			System.out.println("\n"+MenuIsbn);
		}
		
		public void exibirDat() {
			System.out.println("\n"+MenuDat);
		}
		
		/*public void exibirPreco() {
			System.out.println("\n"+MenuPreco);
		}*/
		
		/*public void exibirCateg() {
			System.out.println("\n"+MenuCateg);
		}*/
		
		public void exibirSucLiv() {
			System.out.println("\n"+MenuSucLiv);
		}
		
		public void exibirErrorCateg() {
			System.out.println("\n"+MenuCatError);
		}
		
		// Remover livro
		
			public String MenRlivro = """
					╔═════════════════════════════════════════════╗ 
					    DIGITE O ISBN DO LIVRO PARA REMOVE-LO 📓
					╚═════════════════════════════════════════════╝
					""";
			
			public String MenSRlivro = """
					╔═══════════════════════════════════╗ 
					    LIVRO REMOVIDO COM SUCESSO ✅
					╚═══════════════════════════════════╝
					""";
			
			public String MenRRlivro = """
					╔═══════════════════════════╗ 
					    ISBN NÃO ENCONTRADO ❌
					╚═══════════════════════════╝
					""";
			
		public void exibirRlivro () {
			System.out.println("\n"+MenRlivro);
		}
		
		public void exibirSRlivro () {
			System.out.println("\n"+MenSRlivro);
		}
		
		public void exibirRRlivro () {
			System.out.println("\n"+MenRRlivro);
		}
		
		// Blocos de String's para criar mini interface a ser usado para mostrar ao usuario em cadastro de categoria!

				public String MenuNomCateg = """
						╔═══════════════════════════╗ 
						     NOME DA CATEGORIA 📖
						╚═══════════════════════════╝
						""";
				
				public String MenuDesCateg = """
						╔════════════════════════════╗ 
						   DESCRIÇÃO DA CATEGORIA 📖
						╚════════════════════════════╝
						""";
				
				public String MenuCodCateg = """
						╔═════════════════════════╗ 
						   CODIGO DA CATEGORIA 📖
						╚═════════════════════════╝
						""";
				
				public String MenuCategSuces = """
						╔════════════════════════════════════════╗
						║   CATEGORIA CADASTRADO COM SUCESSO ✅ 	 ║
						╚════════════════════════════════════════╝
						""";
				
			// Metodos ou funções para exibir mini interfaces para melhor visualização de opções
				
			public void exibirNomCateg() {
				System.out.println("\n"+MenuNomCateg);
			}
			
			public void exibirDesCateg() {
				System.out.println("\n"+MenuDesCateg);
			}
			
			public void exibirCodCateg() {
				System.out.println("\n"+MenuCodCateg);
			}
			
			public void exibirCategSuces() {
				System.out.println("\n"+MenuCategSuces);
			}
			
			// Remover Categoria
			
				public String MenRemCateg = """
					╔═════════════════════════════════════════════════╗ 
					   DIGITE O CODIGO DA CATEGORIA PARA REMOVE-LO 📖
					╚═════════════════════════════════════════════════╝
						""";
				
				public String MenRemCategSuces = """
						╔════════════════════════════════════╗ 
						   CATEGORIA REMOVIDO COM SUCESSO ✅
						╚════════════════════════════════════╝
						""";
				
				public String MenCodInvalid = """
						╔═══════════════════════════╗ 
						   CODIGO NÃO ENCONTRADO ❌
						╚═══════════════════════════╝
						""";
					
			public void exibirRemCateg () {
				System.out.println("\n"+MenRemCateg);
			}
			
			public void exibirRemCategSuces () {
				System.out.println("\n"+MenRemCategSuces);
			}
			
			public void exibirCodInvalid () {
				System.out.println("\n"+MenCodInvalid);
			}
			
			
			public String MenAtualSuces = """
					╔════════════════════════════════════╗ 
					  ATUALIZAÇÃO EFETUADA COM SUCESSO ✅
					╚════════════════════════════════════╝
					""";
			
			public void exibirAtualSuces () {
				System.out.println("\n"+MenAtualSuces);
			}
	
}
