package dao;

import java.util.List;

import controller.JPAUtils;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Id;
import jakarta.persistence.NoResultException;
import jakarta.persistence.TypedQuery;
import model.Categoria;
import model.Livro;
import view.Ui;

public class CategoriaDAO {
	
	Ui ui = new Ui();
	
	public Categoria savecat(Categoria cat) { // metodo para cadastrar categoria no BD
		
		EntityManagerFactory emf = JPAUtils.getEntityManagerFactory(); // cria uma variavel do tipo (emf) e chama o metodo para cria-lo
		EntityManager em = emf.createEntityManager(); // pega o (emf) e cria o EntityManager
		
		em.getTransaction().begin(); // inicia uma transição no banco de dados
		em.persist(cat); // salva os dados no (banco de dados)
		em.getTransaction().commit(); // finaliza a transição após confirmação
		em.close(); // fecha o entity manager
		
		return cat;
		
	}
	
	public Boolean deletecat(Integer id) { // metodo para deletar categoria por ID
		
		EntityManagerFactory emf = JPAUtils.getEntityManagerFactory(); // cria o EntityManagerFactory
		EntityManager em = emf.createEntityManager(); // cria o EntityManager
		
		try {
	        em.getTransaction().begin();
	        Categoria categ = em.find(Categoria.class, id); // busca a entidade pelo ID
	        
	        if (categ != null) { // verifica se existe o id
	        	// verifica se tem livros
	        	if (categ.getLivros() != null && !categ.getLivros().isEmpty()) { // (isEmpty) e um método que verifica se a lista está vazia retornando true ou false.
	                em.getTransaction().rollback(); // // desfaz a alteração pendente
	                return false; // se tiver livros não pode excluir
	            }
	            em.remove(categ);
	            em.getTransaction().commit(); // finaliza a transição após confirmação
	            ui.exibirRemCategSuces();
	            return true;
	        } else {
	        	return false; // Categoria não encontrada
	        }
	        
	    } catch (Exception e) {
	        em.getTransaction().rollback();
	        e.printStackTrace();
	        return false;
	    } finally {
	        em.close();
	    }
		
	}
	
	public Categoria updatecat(Categoria upcat) { // metodo para atualizar categoria no BD
		
		EntityManagerFactory emf = JPAUtils.getEntityManagerFactory(); // cria uma variavel do tipo (emf) e chama o metodo para cria-lo
		EntityManager em = emf.createEntityManager(); // pega o (emf) e cria o EntityManager
		
		em.getTransaction().begin(); // inicia uma transição no banco de dados
		em.merge(upcat); // Atualiza os dados no (banco de dados)
		em.getTransaction().commit(); // finaliza a transição após confirmação
		em.close(); // fecha o entity manager
		
		return upcat;
		
	}
	
	public List<Categoria> findAll() {
		String comandoJPQL = "SELECT c FROM Categoria c";
		EntityManagerFactory emf = JPAUtils.getEntityManagerFactory();
		EntityManager em = emf.createEntityManager();
		
		TypedQuery<Categoria> tq = em.createQuery(comandoJPQL, Categoria.class);
		
		return tq.getResultList();
		
	}
	
	public Categoria findById(Integer ctid) {
		String comandoJPQL = "SELECT c FROM Categoria c Where id = :id";
		EntityManagerFactory emf = JPAUtils.getEntityManagerFactory();
		EntityManager em = emf.createEntityManager();
		  
		try {
		      TypedQuery<Categoria> tq = em.createQuery(comandoJPQL, Categoria.class);
		      tq.setParameter("id", ctid);
		      return tq.getSingleResult();
		    } catch (NoResultException e) { // tratamento que evita que a aplicação quebre ao não encontrar o ID.
		        return null;
		    } finally {
				em.close();
			}
	}
	
	public Categoria findByName(String ctname) {
		
		String comandoJPQL = "SELECT c FROM Categoria c Where nome = :nome";
		EntityManagerFactory emf = JPAUtils.getEntityManagerFactory();
		EntityManager em = emf.createEntityManager();
		
		try {
			TypedQuery<Categoria> tq = em.createQuery(comandoJPQL, Categoria.class);
			tq.setParameter("nome", ctname);
			return tq.getSingleResult();
		} catch (NoResultException e) {
			return null;
		} finally {
			em.close();
		}		
	}
	
	public Long countTotalLivros() {
		EntityManagerFactory emf = JPAUtils.getEntityManagerFactory();
		EntityManager em = emf.createEntityManager();
		return em.createQuery("SELECT COUNT(c) FROM Categoria c", Long.class).getSingleResult();
	}


}
