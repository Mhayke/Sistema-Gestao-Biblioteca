package dao;

import java.util.List;

import controller.JPAUtils;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.TypedQuery;
import model.Livro;

public class LivroDAO {
	
	public Livro salvarliv(Livro lv) { // salvar livro no bd
		
		EntityManagerFactory emf = JPAUtils.getEntityManagerFactory();
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		em.persist(lv);
		em.getTransaction().commit();
		em.close();
		
		return lv;
	}
	
	public void deletarByIsbn(String isbn) { // deletar livro por isbn
		
	    EntityManagerFactory emf = JPAUtils.getEntityManagerFactory();
	    EntityManager em = emf.createEntityManager();
	    
	        // Buscar o livro
	        String comandoJPQL = "SELECT l FROM Livro l WHERE l.isbn = :isbn";
	        TypedQuery<Livro> tq = em.createQuery(comandoJPQL, Livro.class);
	        tq.setParameter("isbn", isbn);
	        List<Livro> rl = tq.getResultList();
	        
	        em.getTransaction().begin();

	        // Deletar se encontrado
	        
	        for (Livro livro : rl) {
	            em.remove(em.contains(livro) ? livro : em.merge(livro));
	        }
	        em.getTransaction().commit();
	        em.close();
	    
	}
	
	public Livro atualizarliv(Livro lv) { // atualizar livro no bd
		
		EntityManagerFactory emf = JPAUtils.getEntityManagerFactory();
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		em.merge(lv);
		em.getTransaction().commit();
		em.close();
		
		return lv;
	}
	
	public List<Livro> findAll() { // buscar todos os livros no bd
		String comandoJPQL = "SELECT l FROM Livro l";
		EntityManagerFactory emf = JPAUtils.getEntityManagerFactory();
		EntityManager em = emf.createEntityManager();

		TypedQuery<Livro> tq = em.createQuery(comandoJPQL, Livro.class); // Pesquisa no bd utilizando o JPQL e classe

		return tq.getResultList(); // retorna o resultado TQuary em lista
	}
	
	public List<Livro> findByIsbn(String isbn) { // buscar livro por isbn
		String comandoJPQL = "SELECT l FROM Livro l where isbn = :isbn"; // Where usado para filtrar a pesquisa ou seja 'isbn' por exemplo
		EntityManagerFactory emf = JPAUtils.getEntityManagerFactory();
		EntityManager em = emf.createEntityManager();
		
		TypedQuery<Livro> tq = em.createQuery(comandoJPQL, Livro.class);
		tq.setParameter("isbn", isbn);
		
		return tq.getResultList();
		
	}
	
	public List<Livro> findByAutor(String autor) { // buscar livro por autor
		
		String comandoJPQL = "SELECT l FROM Livro l Where autor = :autor";
		EntityManagerFactory emf = JPAUtils.getEntityManagerFactory();
		EntityManager em = emf.createEntityManager();
	
		TypedQuery<Livro> tq = em.createQuery(comandoJPQL, Livro.class);
		tq.setParameter("autor", autor);
	
		return tq.getResultList();
		
	}

}
