package dao;

import controller.JPAUtils;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import model.Categoria;

public class CategoriaDAO {
	
	public Categoria savecat(Categoria cat) { // metodo para cadastrar categoria no BD
		
		EntityManagerFactory emf = JPAUtils.getEntityManagerFactory(); // cria uma variavel do tipo (emf) e chama o metodo para cria-lo
		EntityManager em = emf.createEntityManager(); // pega o (emf) e cria o EntityManager
		
		em.getTransaction().begin(); // inicia uma transição no banco de dados
		em.persist(cat); // salva os dados no (banco de dados)
		em.getTransaction().commit(); // finaliza a transição após confirmação
		
		return cat;
	}

}
