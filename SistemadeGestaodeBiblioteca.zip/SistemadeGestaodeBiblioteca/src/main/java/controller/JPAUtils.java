package controller;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class JPAUtils {
	
	private static EntityManagerFactory emf = null;
	
	public static EntityManagerFactory getEntityManagerFactory() { // metodo para pegar o emf;
		
		if (emf == null) {
			emf = Persistence.createEntityManagerFactory("SGBFUCTURA-PU");
		}
		
		return emf;
	}

}
