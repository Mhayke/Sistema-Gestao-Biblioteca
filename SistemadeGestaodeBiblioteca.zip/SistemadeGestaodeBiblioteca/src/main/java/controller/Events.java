package controller;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import dao.LivroDAO;
import model.Categoria;
import model.Livro;
import view.Ui;

public class Events {

	public void inicializar() throws SQLException {
		
		Ui ui = new Ui();
		Scanner scan = new Scanner(System.in);
		
		int opt;
		do { // loop de repetição do Menu Principal usando do-While
			ui.exibirMenu();
			System.out.print(" DIGITE UMA OPÇÃO: ");
			opt = scan.nextInt();
			
			switch(opt) { // Opções de casos utilizando os cases do switch!
			
			case 1: // Opção de Gerenciamento de Livro
				
				int optl;
				do {
					ui.exibirGlivros();
					System.out.print(" DIGITE UMA OPÇÃO: ");
					optl = scan.nextInt();
					scan.nextLine(); // limpar o buff
					
					if (optl == 1) { // opção de cadastrar livro
						
						Livro lv = new Livro();
						LivroDAO daolv = new LivroDAO();
						
						ui.exibirNom();
						System.out.print("DIGITE O NOME DO LIVRO: ");
						String titulo = scan.nextLine();
						lv.setTitulo(titulo);
						
						ui.exibirAut();
						System.out.print("DIGITE O NOME DO AUTOR: ");
						String autor = scan.nextLine();
						lv.setAutor(autor);
						
						ui.exibirSinop();
						System.out.print("DIGITE A SINOPSE DO LIVRO: ");
						String sinopse = scan.nextLine();
						lv.setSinopse(sinopse);
						
						ui.exibirIsbn();
						System.out.print("DIGITE O ISBN DO LIVRO: ");
						String isbn = scan.nextLine();
						lv.setIsbn(isbn);    
						
						ui.exibirDat();
						System.out.print("DIGITE A DATA DE LANÇAMENTO DO LIVRO (dd/MM/yyyy): ");
						String anolancamento = scan.nextLine();
						DateTimeFormatter ft = DateTimeFormatter.ofPattern("dd/MM/yyyy"); // formatar a string em localDate
						LocalDate localDate = LocalDate.parse(anolancamento, ft); // transforma string e formato em Localdate
						lv.setAnolancamento(localDate);
						
						/*ui.exibirCateg();
						System.out.print("DIGITE A CATEGORIA DO LIVRO (1-16): ");
						int categ = scan.nextInt();*/
						
						daolv.salvarliv(lv);
						ui.exibirSucLiv(); // mensagem de livro cadastrado.
						
					} else if (optl == 2) { // opção de excluir livro
						
						LivroDAO daolv = new LivroDAO();
						
						ui.exibirRlivro();
						System.out.print("DIGITE O ISBN DO LIVRO PARA (EXCLUSÃO): ");
						String isbn = scan.nextLine();
						
						daolv.deletarByIsbn(isbn);
						
						ui.exibirSRlivro();
						
					} else if (optl == 3) { // opção para atualizar livro
						
						LivroDAO daolv = new LivroDAO();
						
						System.out.print("\nINFORME O ISBN DO LIVRO QUE DESEJA ATUALIZAR: ");
			            String isbnantigo = scan.nextLine();
			         
			            List<Livro> lvant = daolv.findByIsbn(isbnantigo);
			            
			            
			            System.out.print("\nO QUE DESEJA ATUALIZAR ? (titulo, autor, sinopse, isbn, data): ");
			            String campo = scan.nextLine().toLowerCase();
			            
			            if (campo.equalsIgnoreCase("titulo")) {
			            	
			            	ui.exibirNom();
			            	System.out.print("DIGITE O TITULO DO LIVRO PARA (ATUALIZAÇÃO): ");
			            	String titulo = scan.nextLine();
			            	
			            	for (Livro livro : lvant) {
			            		livro.setTitulo(titulo);
			            		daolv.atualizarliv(livro);
							}
			            	
						} else if (campo.equalsIgnoreCase("autor")) {
							
							ui.exibirAut();
							System.out.print("DIGITE O AUTOR DO LIVRO PARA (ATUALIZAÇÃO): ");
							String autor = scan.nextLine();
							
							for (Livro livro : lvant) {
								livro.setAutor(autor);
								daolv.atualizarliv(livro);
							}
							
						} else if (campo.equalsIgnoreCase("sinopse")) {
							
							ui.exibirSinop();
							System.out.print("DIGITE A SINOPSE DO LIVRO PARA (ATUALIZAÇÃO): ");
							String sinopse = scan.nextLine();
							
							for (Livro livro : lvant) {
								livro.setSinopse(sinopse);
								daolv.atualizarliv(livro);
							}
							
						} else if (campo.equalsIgnoreCase("isbn")) {
							
							ui.exibirIsbn();
							System.out.print("DIGITE O ISBN DO LIVRO PARA (ATUALIZAÇÃO): ");
							String isbn = scan.nextLine();
							
							for (Livro livro : lvant) {
								livro.setIsbn(isbn);
								daolv.atualizarliv(livro);
							}
							
						} else if (campo.equalsIgnoreCase("data")) {
							
							ui.exibirDat();
							System.out.print("DIGITE A DATA DO LIVRO PARA ATUALIZAÇÃO (dd/MM/yyyy): ");
							String anoLancamento = scan.nextLine();
							DateTimeFormatter ft = DateTimeFormatter.ofPattern("dd/MM/yyyy"); // formatar a string em localDate
							LocalDate localDate = LocalDate.parse(anoLancamento, ft); // transformar string e Localdate em Date
							
							for (Livro livro : lvant) {
								livro.setAnolancamento(localDate);
								daolv.atualizarliv(livro);
							}
						}
							
					} else if (optl == 4) { // opção para listar todos os livros
							
							LivroDAO daolv = new LivroDAO();
							
							List<Livro> livros = daolv.findAll();
							
							System.out.println("╔═════════════════════════════════════════╗\n"
									+ "	TODOS OS LIVROS CADASTRADOS 📓");
							
							for (Livro ls : livros) {
								
								System.out.println("\n");
								System.out.println("[Código]: " + ls.getCodigo());
								System.out.println("[Título]: " + ls.getTitulo() + " [Autor]: " + ls.getAutor() + " [ISBN]: " + ls.getIsbn());
								System.out.println("[Sinopse]: " + ls.getSinopse());
								System.out.println("[Ano de Lançamento]: " + ls.getAnolancamento() + " [Categoria]: ");
								
							}
							System.out.println("\n");
							System.out.println("\n╚═════════════════════════════════════════╝");
							
					} else if (optl == 5) { // opção para buscar livro por isbn
						
						LivroDAO daolv = new LivroDAO();
						
						System.out.print("\nQUAL O (ISBN) QUE DESEJA BUSCAR?: ");
						String isbn = scan.nextLine();
						
						List<Livro> livro = daolv.findByIsbn(isbn);
						
						for (Livro ls : livro) {
							System.out.println("\n╔═════════════════════════════════════════╗");
							System.out.println("    RESULTADO DO ISBN:"+ ls.getIsbn() + " ENCONTRADO!\n");
							System.out.println("[Código]: " + ls.getCodigo());
							System.out.println("[Título]: " + ls.getTitulo() + " [Autor]: " + ls.getAutor() + " [ISBN]: " + ls.getIsbn());
							System.out.println("[Sinopse]: " + ls.getSinopse());
							System.out.println("[Ano de Lançamento]: " + ls.getAnolancamento() + " [Categoria]: ");
							System.out.println("\n╚═════════════════════════════════════════╝");
						}
						
					} else if (optl == 6) { // opção para buscar livro por autor
						
						LivroDAO daolv = new LivroDAO();
						
						System.out.print("\nQUAL O (NOME) DO AUTOR QUE DESEJA BUSCAR?: ");
						String autor = scan.nextLine();
						
						List<Livro> livro = daolv.findByAutor(autor);
						
						System.out.println("\n╔═════════════════════════════════════════╗");
						System.out.println("        RESULTADO DO AUTOR:"+ autor + " 📓\n");
						
						for (Livro ls : livro) {
							System.out.println("[Código]: " + ls.getCodigo());
							System.out.println("[Título]: " + ls.getTitulo() + " [Autor]: " + ls.getAutor() + " [ISBN]: " + ls.getIsbn());
							System.out.println("[Sinopse]: " + ls.getSinopse());
							System.out.println("[Ano de Lançamento]: " + ls.getAnolancamento() + " [Categoria]: ");
							System.out.println("\n");
						}
						System.out.println("╚═════════════════════════════════════════╝");
						
					} else if (optl == 7) {
						continue;
						
					} else if (optl == 8) { // opção para voltar ao menu principal
						break; // encerra o loop do-while
					} else {
						ui.exibir404invalid(); // exibe mensagem de 'opção invalida'
					}
					
				} while (optl != 8);
				
				break; // encerra o switch case
				
			case 2: // Opção de Gerenciamento de Categoria
				
				int optc;
				do {
					ui.exibirGcategoria();
					System.out.print(" DIGITE UMA OPÇÃO: ");
					optc = scan.nextInt();
					scan.nextLine(); // limpar o buff
					
					if (optc == 1) { // opção de cadastrar categoria
						ui.exibirNomCateg();
						System.out.print("DIGITE O NOME DA CATEGORIA: ");
						String nome = scan.nextLine();
						
						ui.exibirDesCateg();
						System.out.print("DIGITE A DESCRIÇÃO DA CATEGORIA: ");
						String desc = scan.nextLine();
						
						ui.exibirCodCateg();
						System.out.print("DIGITE O CODIGO DA CATEGORIA: ");
						int cod = scan.nextInt();
						
						ui.exibirCategSuces();
						
					} else if (optc == 2) { // opção de excluir categoria
						
						ui.exibirRemCateg();
						System.out.print("DIGITE O CODIGO DA CATEGORIA PARA (EXCLUSÃO): ");
						int cod = scan.nextInt();
						
						ui.exibirRemCategSuces();
						
					} else if (optc == 3) { // opção para atualizar categoria
						
						ui.exibirCodCateg();
						System.out.print("\nINFORME O CODIGO DA CATEGORIA QUE DESEJA (ATUALIZAR): ");
			            int codant = scan.nextInt();

			            System.out.print("\nO QUE DESEJA ATUALIZAR ? (nome, descricao, codigo): ");
			            String campo = scan.nextLine().toLowerCase();
			            
			            if (campo.equalsIgnoreCase("nome")) {
			            	ui.exibirNomCateg();
			            	System.out.print("DIGITE O NOME DA CATEGORIA PARA (ATUALIZAÇÃO): ");
			            	String nome = scan.nextLine();
			            	
						} else if (campo.equalsIgnoreCase("descricao")) {
							ui.exibirDesCateg();
							System.out.print("DIGITE A DESCRIÇÃO DA CATEGORIA PARA (ATUALIZAÇÃO): ");
							String desc = scan.nextLine();
							
						} else if (campo.equalsIgnoreCase("codigo")) {
							ui.exibirCodCateg();
							System.out.print("DIGITE O CODIGO DA CATEGORIA PARA (ATUALIZAÇÃO): ");
							int cod = scan.nextInt();
							
						} else if (optc == 4) {
							continue;
						}
						else {
							ui.exibir404invalid();
						}
			            
					} else if (optc == 5) {
						break; // encerra o loop do-while
					} 
					else {
						ui.exibir404invalid(); // exibe mensagem de 'opção invalida'
					}
					
				} while (optc != 5);
				
				break; // encerra o switch case
				
			case 3: // Finaliza o loop do-While e encerra o programa.
				ui.exibirSaida();
				return;
			
			default: // Quando não ha uma opção numerica valida! 
				ui.exibir404invalid();
			}
			
		} while (opt != 3); // Condição de encerrar o programa.
	}
	
}
