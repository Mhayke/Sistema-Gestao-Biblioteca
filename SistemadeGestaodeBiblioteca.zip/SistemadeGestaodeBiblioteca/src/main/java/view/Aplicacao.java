package view;

import java.sql.SQLException;

import controller.Events;

public class Aplicacao {

	public static void main(String[] args) throws SQLException {
		
		Events ev = new Events();
		ev.inicializar(); // Metodo de Evento para inicializar o programa.
		
	}

}
