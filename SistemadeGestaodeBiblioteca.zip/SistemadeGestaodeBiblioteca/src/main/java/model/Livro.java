package model;

import java.time.LocalDate;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity // determina a classe "Livro" como uma tabela
public class Livro {
	
	@Id // define a (primary key)
	@GeneratedValue
	private Integer codigo;
	
	@Column(nullable= false) // 'nullable' para obrigação do preenchimento de campo
	private String titulo;
	
	@Column(nullable= false)
	private String autor;
	
	@Column(nullable= false)
	private String sinopse;
	
	@Column(nullable= false, unique = true, length = 13) // 'unique' para deixar o campo unico no bd, 'lengh' tamanho max.
	private String isbn;
	
	@Column(nullable= false)
	private LocalDate anolancamento;

	
	// gett's e sett's
	
	public Integer getCodigo() {
		return codigo;
	}

	public LocalDate getAnolancamento() {
		return anolancamento;
	}

	public void setAnolancamento(LocalDate anolancamento) {
		this.anolancamento = anolancamento;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public String getSinopse() {
		return sinopse;
	}

	public void setSinopse(String sinopse) {
		this.sinopse = sinopse;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}


}
